// Adding event listener for the 'Add Numbers' button
document.getElementById('calculateBtn').addEventListener('click', function() {
    // Step 1: Declare variables to store input values
    let num1 = document.getElementById('number1').value; // getting first input value
    let num2 = document.getElementById('number2').value; // getting second input value
    // Step 2: Convert the input values from strings to numbers
    num1 = Number(num1);  // converting the first input to a number
    num2 = Number(num2);  // converting the second input to a number
    // Step 3: Add the two numbers and store the result in a new variable
    let sum = num1 + num2; // storing the result of addition in the 'sum' variable
    // Step 4: Display the result in the paragraph with id 'result'
    document.getElementById('result').textContent = 'The sum is: ' + sum;
});
