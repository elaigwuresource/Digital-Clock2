// JavaScript programs and statements
// Program 1: Change Text Content
document.getElementById('changeTextBtn').addEventListener('click', function() {
    // JavaScript statement: Changing the text of the <p> element
    document.getElementById('message').textContent = 'JavaScript changed it to a new content!';
});

// Program 2: Basic Calculation
document.getElementById('calculateBtn').addEventListener('click', function() {
    // JavaScript statements: Performing a calculation and displaying the result
    let num1 = 1500;
    let num2 = 2000;
    let result = num1 + num2; // statement: performing the addition
    alert('The result of 1500 + 2000 is: ' + result); // statement: displaying the result in an alert box
});
